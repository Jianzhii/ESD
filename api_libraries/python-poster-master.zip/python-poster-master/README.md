# python-poster

Streaming HTTP uploads and multipart/form-data encoding

## This exists as a friendly fork for Python 3 compatibility. I don't maintain it actively or accept PRs. You are welcome to fork it to apply your changes. Use it at your own risk.
